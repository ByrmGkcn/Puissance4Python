class joueur :
    nom : str
    score : int
    typo : str
    mode : str

class bcolors:
    OKRED = '\033[91m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    OKMAGENTA = "\033[35m"
    OKYELLOW = "\033[33m"
    LightMagenta = "\033[95m"
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'